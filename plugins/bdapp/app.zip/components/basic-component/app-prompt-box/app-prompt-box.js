(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/basic-component/app-prompt-box/app-prompt-box"],{"285b":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"app-prompt-box",props:{text:{type:String}},methods:{close:function(t){this.$emit("click",t)}}};n.default=a},"287f":function(t,n,e){"use strict";e.r(n);var a=e("285b"),o=e.n(a);for(var r in a)"default"!==r&&function(t){e.d(n,t,function(){return a[t]})}(r);n["default"]=o.a},"387a":function(t,n,e){"use strict";e.r(n);var a=e("3f27"),o=e("287f");for(var r in o)"default"!==r&&function(t){e.d(n,t,function(){return o[t]})}(r);e("a5ca");var u=e("2877"),c=Object(u["a"])(o["default"],a["a"],a["b"],!1,null,"330b140c",null);n["default"]=c.exports},"3f27":function(t,n,e){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},o=[];e.d(n,"a",function(){return a}),e.d(n,"b",function(){return o})},"8e86":function(t,n,e){},a5ca:function(t,n,e){"use strict";var a=e("8e86"),o=e.n(a);o.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/basic-component/app-prompt-box/app-prompt-box-create-component',
    {
        'components/basic-component/app-prompt-box/app-prompt-box-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("387a"))
        })
    },
    [['components/basic-component/app-prompt-box/app-prompt-box-create-component']]
]);                
