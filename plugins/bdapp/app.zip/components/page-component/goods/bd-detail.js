(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/goods/bd-detail"],{"3e70":function(t,e,n){"use strict";n.r(e);var c=n("decd"),o=n("41ce");for(var r in o)"default"!==r&&function(t){n.d(e,t,function(){return o[t]})}(r);n("587b");var a=n("2877"),i=Object(a["a"])(o["default"],c["a"],c["b"],!1,null,"e6712924",null);e["default"]=i.exports},"41ce":function(t,e,n){"use strict";n.r(e);var c=n("9c68"),o=n.n(c);for(var r in c)"default"!==r&&function(t){n.d(e,t,function(){return c[t]})}(r);e["default"]=o.a},"587b":function(t,e,n){"use strict";var c=n("c024"),o=n.n(c);o.a},"9c68":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var c=function(){return Promise.all([n.e("common/vendor"),n.e("components/basic-component/app-rich/parse")]).then(n.bind(null,"cb0e"))},o={name:"bd-detail",components:{"app-rich-text":c},props:{detail:{type:String,default:function(){return""}}},created:function(){this.$store.dispatch("gConfig/setImageWidth",48)},computed:{newDetail:function(){var t="";return this.detail&&(t=this.detail),t}}};e.default=o},c024:function(t,e,n){},decd:function(t,e,n){"use strict";var c=function(){var t=this,e=t.$createElement;t._self._c},o=[];n.d(e,"a",function(){return c}),n.d(e,"b",function(){return o})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/goods/bd-detail-create-component',
    {
        'components/page-component/goods/bd-detail-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("3e70"))
        })
    },
    [['components/page-component/goods/bd-detail-create-component']]
]);                
