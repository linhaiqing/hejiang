(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/u-index-plugins/u-index-plugins"],{"03c5":function(n,t,e){"use strict";e.r(t);var u=e("f111"),r=e("505b");for(var i in r)"default"!==i&&function(n){e.d(t,n,function(){return r[n]})}(i);e("06be");var a=e("2877"),o=Object(a["a"])(r["default"],u["a"],u["b"],!1,null,"b86704ec",null);t["default"]=o.exports},"06be":function(n,t,e){"use strict";var u=e("4e85"),r=e.n(u);r.a},"4e85":function(n,t,e){},"505b":function(n,t,e){"use strict";e.r(t);var u=e("df27"),r=e.n(u);for(var i in u)"default"!==i&&function(n){e.d(t,n,function(){return u[n]})}(i);t["default"]=r.a},df27:function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var e={name:"u-index-plugins",props:{list:{type:Array},url:{type:String}},methods:{router:function(){n.navigateTo({url:this.url})}}};t.default=e}).call(this,e("5486")["default"])},f111:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return r})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/u-index-plugins/u-index-plugins-create-component',
    {
        'components/page-component/u-index-plugins/u-index-plugins-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("03c5"))
        })
    },
    [['components/page-component/u-index-plugins/u-index-plugins-create-component']]
]);                
