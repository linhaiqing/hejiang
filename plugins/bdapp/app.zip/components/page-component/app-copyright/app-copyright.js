(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-copyright/app-copyright"],{"33f0":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"app-copyright",props:{backgroundColor:{type:String,default:function(){return"#ff4544"}},link:{type:Object,default:function(){return null}},picUrl:String,text:String}};n.default=r},"53a9":function(t,n,e){"use strict";var r=e("c41b"),u=e.n(r);u.a},"7d10":function(t,n,e){"use strict";e.r(n);var r=e("33f0"),u=e.n(r);for(var c in r)"default"!==c&&function(t){e.d(n,t,function(){return r[t]})}(c);n["default"]=u.a},"7fe8":function(t,n,e){"use strict";e.r(n);var r=e("ccf0"),u=e("7d10");for(var c in u)"default"!==c&&function(t){e.d(n,t,function(){return u[t]})}(c);e("53a9");var a=e("2877"),o=Object(a["a"])(u["default"],r["a"],r["b"],!1,null,"34182b3a",null);n["default"]=o.exports},c41b:function(t,n,e){},ccf0:function(t,n,e){"use strict";var r=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return r}),e.d(n,"b",function(){return u})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-copyright/app-copyright-create-component',
    {
        'components/page-component/app-copyright/app-copyright-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("7fe8"))
        })
    },
    [['components/page-component/app-copyright/app-copyright-create-component']]
]);                
