(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-order-goods-info/app-order-goods-info"],{1602:function(t,e,n){"use strict";n.r(e);var a=n("40b5"),u=n("9c56");for(var o in u)"default"!==o&&function(t){n.d(e,t,function(){return u[t]})}(o);n("6411");var r=n("2877"),f=Object(r["a"])(u["default"],a["a"],a["b"],!1,null,"77973d38",null);e["default"]=f.exports},"1a80":function(t,e,n){},"40b5":function(t,e,n){"use strict";var a=function(){var t=this,e=t.$createElement;t._self._c},u=[];n.d(e,"a",function(){return a}),n.d(e,"b",function(){return u})},"5a2d":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={name:"app-order-goods-info",data:function(){return{}},props:{goods:{type:Object,default:{}},plugin:{type:String,default:""},isLastOne:{type:Boolean,default:!0},pluginData:{type:Object,default:{}},pluginIndex:{type:Number,default:0},type:{type:Number,default:1}}};e.default=a},6411:function(t,e,n){"use strict";var a=n("1a80"),u=n.n(a);u.a},"9c56":function(t,e,n){"use strict";n.r(e);var a=n("5a2d"),u=n.n(a);for(var o in a)"default"!==o&&function(t){n.d(e,t,function(){return a[t]})}(o);e["default"]=u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-order-goods-info/app-order-goods-info-create-component',
    {
        'components/page-component/app-order-goods-info/app-order-goods-info-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("1602"))
        })
    },
    [['components/page-component/app-order-goods-info/app-order-goods-info-create-component']]
]);                
