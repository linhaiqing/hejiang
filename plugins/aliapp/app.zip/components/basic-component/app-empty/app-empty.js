;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/basic-component/app-empty/app-empty"],{"6de2":function(t,n,e){"use strict";var u=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"a",function(){return u}),e.d(n,"b",function(){return r})},7779:function(t,n,e){"use strict";var u=e("b372"),r=e.n(u);r.a},8048:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"app-empty",props:{height:{type:Number,default:function(){return 10}},backgroundColor:{type:String,default:function(){return"#ffffff"}}}};n.default=u},a7c3:function(t,n,e){"use strict";e.r(n);var u=e("6de2"),r=e("bc75");for(var a in r)"default"!==a&&function(t){e.d(n,t,function(){return r[t]})}(a);e("7779");var f=e("2877"),c=Object(f["a"])(r["default"],u["a"],u["b"],!1,null,"6f74ea11",null);n["default"]=c.exports},b372:function(t,n,e){},bc75:function(t,n,e){"use strict";e.r(n);var u=e("8048"),r=e.n(u);for(var a in u)"default"!==a&&function(t){e.d(n,t,function(){return u[t]})}(a);n["default"]=r.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/basic-component/app-empty/app-empty-create-component',
    {
        'components/basic-component/app-empty/app-empty-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("a7c3"))
        })
    },
    [['components/basic-component/app-empty/app-empty-create-component']]
]);                
