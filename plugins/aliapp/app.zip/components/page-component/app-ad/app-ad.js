;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-ad/app-ad"],{3441:function(n,t,e){},4961:function(n,t,e){"use strict";var r=function(){var n=this,t=n.$createElement;n._self._c},o=[];e.d(t,"a",function(){return r}),e.d(t,"b",function(){return o})},ba36:function(n,t,e){"use strict";e.r(t);var r=e("4961"),o=e("bcb4");for(var u in o)"default"!==u&&function(n){e.d(t,n,function(){return o[n]})}(u);e("e257");var a=e("2877"),c=Object(a["a"])(o["default"],r["a"],r["b"],!1,null,"8c155a3e",null);t["default"]=c.exports},bcb4:function(n,t,e){"use strict";e.r(t);var r=e("d462"),o=e.n(r);for(var u in r)"default"!==u&&function(n){e.d(t,n,function(){return r[n]})}(u);t["default"]=o.a},d462:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"app-ad",props:{type:String,unitId:String,picUrl:String,videoUrl:String},methods:{onAdLoad:function(){},onAdPlay:function(){},onAdClose:function(){},onAdError:function(){}}};t.default=r},e257:function(n,t,e){"use strict";var r=e("3441"),o=e.n(r);o.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-ad/app-ad-create-component',
    {
        'components/page-component/app-ad/app-ad-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("ba36"))
        })
    },
    [['components/page-component/app-ad/app-ad-create-component']]
]);                
