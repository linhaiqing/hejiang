;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-goods-poster/app-poster-price"],{2e3:function(e,t,n){"use strict";n.r(t);var o=n("3eb79"),r=n.n(o);for(var u in o)"default"!==u&&function(e){n.d(t,e,function(){return o[e]})}(u);t["default"]=r.a},"3eb79":function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=function(){return n.e("components/page-component/goods/app-price").then(n.bind(null,"6c9f"))},r={components:{appPrice:o},props:{whiteColor:{type:Boolean,required:!1},info:{type:Object,required:!0},textColor:{type:String,default:"#FF4544",required:!1}},data:function(){return{defaultPrice:["booking","","miaosha","mch","pick"]}}};t.default=r},a87b:function(e,t,n){"use strict";var o=function(){var e=this,t=e.$createElement,n=(e._self._c,e.defaultPrice.indexOf(e.info.sign));e.$mp.data=Object.assign({},{$root:{g0:n}})},r=[];n.d(t,"a",function(){return o}),n.d(t,"b",function(){return r})},b30d:function(e,t,n){"use strict";n.r(t);var o=n("a87b"),r=n("2000");for(var u in r)"default"!==u&&function(e){n.d(t,e,function(){return r[e]})}(u);n("e1ff");var a=n("2877"),i=Object(a["a"])(r["default"],o["a"],o["b"],!1,null,"ce0cdd4e",null);t["default"]=i.exports},d463:function(e,t,n){},e1ff:function(e,t,n){"use strict";var o=n("d463"),r=n.n(o);r.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-goods-poster/app-poster-price-create-component',
    {
        'components/page-component/app-goods-poster/app-poster-price-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("b30d"))
        })
    },
    [['components/page-component/app-goods-poster/app-poster-price-create-component']]
]);                
