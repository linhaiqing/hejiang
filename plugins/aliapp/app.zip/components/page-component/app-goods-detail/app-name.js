;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-goods-detail/app-name"],{"0db8":function(n,t,e){},1691:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a={name:"name",props:{name:String}};t.default=a},"1caa":function(n,t,e){"use strict";e.r(t);var a=e("45b2"),u=e("b8eb");for(var r in u)"default"!==r&&function(n){e.d(t,n,function(){return u[n]})}(r);e("3a95");var c=e("2877"),o=Object(c["a"])(u["default"],a["a"],a["b"],!1,null,"58b7e9c0",null);t["default"]=o.exports},"3a95":function(n,t,e){"use strict";var a=e("0db8"),u=e.n(a);u.a},"45b2":function(n,t,e){"use strict";var a=function(){var n=this,t=n.$createElement;n._self._c},u=[];e.d(t,"a",function(){return a}),e.d(t,"b",function(){return u})},b8eb:function(n,t,e){"use strict";e.r(t);var a=e("1691"),u=e.n(a);for(var r in a)"default"!==r&&function(n){e.d(t,n,function(){return a[n]})}(r);t["default"]=u.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-goods-detail/app-name-create-component',
    {
        'components/page-component/app-goods-detail/app-name-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("1caa"))
        })
    },
    [['components/page-component/app-goods-detail/app-name-create-component']]
]);                
