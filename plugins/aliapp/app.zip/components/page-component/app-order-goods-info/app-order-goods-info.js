;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-order-goods-info/app-order-goods-info"],{"133b":function(t,e,n){"use strict";var u=function(){var t=this,e=t.$createElement;t._self._c},a=[];n.d(e,"a",function(){return u}),n.d(e,"b",function(){return a})},1602:function(t,e,n){"use strict";n.r(e);var u=n("133b"),a=n("9c56");for(var o in a)"default"!==o&&function(t){n.d(e,t,function(){return a[t]})}(o);n("6411");var r=n("2877"),f=Object(r["a"])(a["default"],u["a"],u["b"],!1,null,"77973d38",null);e["default"]=f.exports},"1a80":function(t,e,n){},"5a2d":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"app-order-goods-info",data:function(){return{}},props:{goods:{type:Object,default:{}},plugin:{type:String,default:""},isLastOne:{type:Boolean,default:!0},pluginData:{type:Object,default:{}},pluginIndex:{type:Number,default:0},type:{type:Number,default:1}}};e.default=u},6411:function(t,e,n){"use strict";var u=n("1a80"),a=n.n(u);a.a},"9c56":function(t,e,n){"use strict";n.r(e);var u=n("5a2d"),a=n.n(u);for(var o in u)"default"!==o&&function(t){n.d(e,t,function(){return u[t]})}(o);e["default"]=a.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-order-goods-info/app-order-goods-info-create-component',
    {
        'components/page-component/app-order-goods-info/app-order-goods-info-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("1602"))
        })
    },
    [['components/page-component/app-order-goods-info/app-order-goods-info-create-component']]
]);                
