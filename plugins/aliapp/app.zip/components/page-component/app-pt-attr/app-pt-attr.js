;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-pt-attr/app-pt-attr"],{"051f":function(t,e,n){"use strict";n.r(e);var r=n("5659"),u=n("5dbd");for(var c in u)"default"!==c&&function(t){n.d(e,t,function(){return u[t]})}(c);n("ec12");var a=n("2877"),o=Object(a["a"])(u["default"],r["a"],r["b"],!1,null,"632c8470",null);e["default"]=o.exports},5659:function(t,e,n){"use strict";var r=function(){var t=this,e=t.$createElement;t._self._c},u=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return u})},"5dbd":function(t,e,n){"use strict";n.r(e);var r=n("e9a6"),u=n.n(r);for(var c in r)"default"!==c&&function(t){n.d(e,t,function(){return r[t]})}(c);e["default"]=u.a},7363:function(t,e,n){},e9a6:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"app-pt-attr",props:{groups:{type:Array,default:function(){return[]}},selectGroupAttrId:String,theme:Object},methods:{active:function(t){this.$emit("click",t)}},computed:{select:function(){return this.selectGroupAttrId}}};e.default=r},ec12:function(t,e,n){"use strict";var r=n("7363"),u=n.n(r);u.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-pt-attr/app-pt-attr-create-component',
    {
        'components/page-component/app-pt-attr/app-pt-attr-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("051f"))
        })
    },
    [['components/page-component/app-pt-attr/app-pt-attr-create-component']]
]);                
