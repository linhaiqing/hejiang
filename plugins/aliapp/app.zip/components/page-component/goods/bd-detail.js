;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/goods/bd-detail"],{"3e70":function(t,e,n){"use strict";n.r(e);var c=n("decd"),r=n("41ce");for(var i in r)"default"!==i&&function(t){n.d(e,t,function(){return r[t]})}(i);n("587b");var o=n("2877"),u=Object(o["a"])(r["default"],c["a"],c["b"],!1,null,"e6712924",null);e["default"]=u.exports},"41ce":function(t,e,n){"use strict";n.r(e);var c=n("9c68"),r=n.n(c);for(var i in c)"default"!==i&&function(t){n.d(e,t,function(){return c[t]})}(i);e["default"]=r.a},"587b":function(t,e,n){"use strict";var c=n("c024"),r=n.n(c);r.a},"9c68":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var c=function(){return Promise.all([n.e("common/vendor"),n.e("components/basic-component/app-rich/parse")]).then(n.bind(null,"cb0e"))},r={name:"bd-detail",components:{"app-rich-text":c},props:{detail:{type:String,default:function(){return""}}},created:function(){this.$store.dispatch("gConfig/setImageWidth",48)},computed:{newDetail:function(){var t="";return this.detail&&(t=this.detail),t}}};e.default=r},c024:function(t,e,n){},decd:function(t,e,n){"use strict";var c=function(){var t=this,e=t.$createElement;t._self._c},r=[];n.d(e,"a",function(){return c}),n.d(e,"b",function(){return r})}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/goods/bd-detail-create-component',
    {
        'components/page-component/goods/bd-detail-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("3e70"))
        })
    },
    [['components/page-component/goods/bd-detail-create-component']]
]);                
