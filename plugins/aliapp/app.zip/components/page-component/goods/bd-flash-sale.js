;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/goods/bd-flash-sale"],{"0b5e":function(t,e,a){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={name:"bd-flash-sale",props:{flashSale:{type:Object,default:function(){return{time_status:1,start_at:"",end_at:"",min_discount:""}}},theme:Object},computed:{flashStyle:function(){return"a"==this.theme.theme&&this.flashSale.cover?"background-image: url('"+this.flashSale.cover+")":"background:"+this.theme.background_p}},methods:{navigator:function(){t.navigateTo({url:this.flashSale.url})}}};e.default=a}).call(this,a("c11b")["default"])},"28dc":function(t,e,a){"use strict";a.r(e);var n=a("0b5e"),u=a.n(n);for(var r in n)"default"!==r&&function(t){a.d(e,t,function(){return n[t]})}(r);e["default"]=u.a},"87eba":function(t,e,a){"use strict";var n=function(){var t=this,e=t.$createElement;t._self._c},u=[];a.d(e,"a",function(){return n}),a.d(e,"b",function(){return u})},"975a":function(t,e,a){"use strict";a.r(e);var n=a("87eba"),u=a("28dc");for(var r in u)"default"!==r&&function(t){a.d(e,t,function(){return u[t]})}(r);a("fa8a");var c=a("2877"),o=Object(c["a"])(u["default"],n["a"],n["b"],!1,null,"99165a04",null);e["default"]=o.exports},fa8a:function(t,e,a){"use strict";var n=a("fed7"),u=a.n(n);u.a},fed7:function(t,e,a){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/goods/bd-flash-sale-create-component',
    {
        'components/page-component/goods/bd-flash-sale-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("975a"))
        })
    },
    [['components/page-component/goods/bd-flash-sale-create-component']]
]);                
