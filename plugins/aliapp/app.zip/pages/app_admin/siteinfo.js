module.exports = {
    'acid': -1,
    'version': '1.0.0',
    'siteroot': 'http://localhost/app/index.php',
    'apiroot': 'http://localhost/web/index.php?_mall_id=1',
};
