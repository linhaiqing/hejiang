;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["pages/cats/style-four"],{"35cc":function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=function(){return e.e("components/page-component/app-category-list/app-category-list").then(e.bind(null,"5d3f"))},u=function(){return e.e("components/page-component/app-no-goods/app-no-goods").then(e.bind(null,"8112"))},a={name:"style-four",components:{"app-category-list":o,"app-no-goods":u},props:["list","activeIndex","setHeight","theme"],methods:{active:function(t){var n=t.item;this.$emit("active",n)},route_go:function(n){n&&t.navigateTo({url:n})},route_advert:function(t){this.$emit("route_advert",t)}}};n.default=a}).call(this,e("c11b")["default"])},3619:function(t,n,e){"use strict";var o=e("3e95"),u=e.n(o);u.a},"38f6":function(t,n,e){"use strict";e.r(n);var o=e("35cc"),u=e.n(o);for(var a in o)"default"!==a&&function(t){e.d(n,t,function(){return o[t]})}(a);n["default"]=u.a},"3d08":function(t,n,e){"use strict";var o=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return o}),e.d(n,"b",function(){return u})},"3e95":function(t,n,e){},"59d9":function(t,n,e){"use strict";e.r(n);var o=e("3d08"),u=e("38f6");for(var a in u)"default"!==a&&function(t){e.d(n,t,function(){return u[t]})}(a);e("3619");var c=e("2877"),r=Object(c["a"])(u["default"],o["a"],o["b"],!1,null,"3a6c3efc",null);n["default"]=r.exports}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'pages/cats/style-four-create-component',
    {
        'pages/cats/style-four-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("59d9"))
        })
    },
    [['pages/cats/style-four-create-component']]
]);                
